import { Link } from 'react-router-dom';
import usePageTitle from '../hooks/usePageTitle.js';

export default function NotFound() {
  usePageTitle('Page not found');
  return (
    <section className="section">
      <div className="container empty">
        <h1 className="empty__title">That page doesn't exist</h1>
        <p className="empty__text">The link may be broken or the page may have moved.</p>
        <div className="empty__actions">
          <Link to="/" className="btn btn--primary">Back to Home</Link>
          <Link to="/explore" className="btn btn--secondary">Explore Skills</Link>
        </div>
      </div>
    </section>
  );
}
