export default function CategoryFilter({ categories, active, onChange, counts }) {
  return (
    <div className="filters" role="group" aria-label="Filter by category">
      {categories.map((category) => (
        <button
          key={category}
          type="button"
          className={`filter-chip${active === category ? ' is-active' : ''}`}
          aria-pressed={active === category}
          onClick={() => onChange(category)}
        >
          {category}
          <span className="filter-chip__count">{counts[category] ?? 0}</span>
        </button>
      ))}
    </div>
  );
}
