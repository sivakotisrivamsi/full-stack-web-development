import { CloseIcon, SearchIcon } from './Icons.jsx';

export default function SearchBar({ value, onChange, placeholder = 'Search skills or people' }) {
  return (
    <div className="search">
      <SearchIcon className="search__icon" />
      <input
        type="search"
        className="search__input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        aria-label="Search skills or people"
      />
      {value && (
        <button type="button" className="search__clear" onClick={() => onChange('')} aria-label="Clear search">
          <CloseIcon width={16} height={16} />
        </button>
      )}
    </div>
  );
}
