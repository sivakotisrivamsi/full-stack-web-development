import { sampleProfiles } from '../data/sampleData.js';
import SkillCard from './SkillCard.jsx';
import { SwapIcon } from './Icons.jsx';

// Two members whose skills match each other, shown in the hero as an example of a swap
const first = sampleProfiles.find((p) => p.id === 'p1');
const second = sampleProfiles.find((p) => p.id === 'p9');

export default function SwapVisual() {
  return (
    <div className="swap-visual" aria-label="Example of a skill swap between two members">
      <div className="swap-visual__item swap-visual__item--first">
        <SkillCard profile={first} preview />
      </div>
      <span className="swap-visual__badge" aria-hidden="true">
        <SwapIcon width={22} height={22} />
      </span>
      <div className="swap-visual__item swap-visual__item--second">
        <SkillCard profile={second} preview />
      </div>
    </div>
  );
}
