import { Link } from 'react-router-dom';

export default function Logo({ light = false }) {
  return (
    <Link to="/" className={`logo${light ? ' logo--light' : ''}`} aria-label="SkillSwap home">
      <svg className="logo__mark" viewBox="0 0 40 40" aria-hidden="true" focusable="false">
        <rect width="40" height="40" rx="12" fill={light ? '#FFFFFF' : '#6B3FD4'} />
        <path
          d="M11 16h15l-4.5-4.5M29 24H14l4.5 4.5"
          fill="none"
          stroke={light ? '#6B3FD4' : '#FFFFFF'}
          strokeWidth="2.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="31" cy="10" r="3.2" fill="#8AD0FF" />
      </svg>
      <span className="logo__text">SkillSwap</span>
    </Link>
  );
}
