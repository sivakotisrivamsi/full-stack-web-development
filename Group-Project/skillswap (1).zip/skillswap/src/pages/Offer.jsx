import { useState } from 'react';
import { Link } from 'react-router-dom';
import usePageTitle from '../hooks/usePageTitle.js';
import { useSkillSwap } from '../context/SkillSwapContext.jsx';
import { EMPTY_VALUES, parseSkills } from '../utils/validation.js';
import SkillForm from '../components/SkillForm.jsx';
import SkillCard from '../components/SkillCard.jsx';
import { CheckIcon } from '../components/Icons.jsx';

export default function Offer() {
  usePageTitle('Offer Your Skill');
  const { addProfile } = useSkillSwap();
  const [draft, setDraft] = useState(EMPTY_VALUES);
  const [created, setCreated] = useState(null);

  const handleSubmit = (data) => {
    setCreated(addProfile(data));
  };

  // Build the live preview from whatever has been typed so far
  const teaches = parseSkills(draft.teaches);
  const learns = parseSkills(draft.learns);
  const preview = {
    id: 'preview',
    name: draft.name.trim() || 'Your name',
    category: draft.category || 'Category',
    level: draft.level,
    teaches: teaches.length ? teaches : ['Your skill'],
    learns: learns.length ? learns : ['Something new'],
    bio: draft.bio.trim() || 'Your short note will appear here.',
  };

  return (
    <>
      <section className="page-header">
        <div className="container">
          <h1 className="page-header__title">Offer Your Skill</h1>
          <p className="page-header__lead">
            Tell the community what you can teach and what you want to learn. Your profile appears in Explore Skills right away.
          </p>
        </div>
      </section>

      <section className="section section--compact">
        <div className="container offer-layout">
          <div className="offer-layout__form">
            {created && (
              <div className="success" role="status">
                <span className="success__icon"><CheckIcon width={20} height={20} /></span>
                <div>
                  <p className="success__title">You're on the list, {created.name}!</p>
                  <p className="success__text">
                    Your profile is now live with {created.teaches.join(', ')} on offer.{' '}
                    <Link className="success__link" to={`/explore?q=${encodeURIComponent(created.name)}`}>View it in Explore Skills</Link>
                  </p>
                </div>
              </div>
            )}
            <SkillForm onSubmit={handleSubmit} onValuesChange={setDraft} />
          </div>

          <aside className="offer-layout__preview" aria-label="Profile preview">
            <h2 className="offer-layout__preview-title">Live preview</h2>
            <SkillCard profile={preview} preview />
            <p className="offer-layout__tip">
              Tip: profiles that name specific skills, like "Figma" instead of "design", get matched faster.
            </p>
          </aside>
        </div>
      </section>
    </>
  );
}
