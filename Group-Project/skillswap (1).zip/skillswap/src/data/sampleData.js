// Sample data shown the first time the app loads.
// After that, everything lives in localStorage.

export const CATEGORIES = ['Programming', 'Design', 'Language', 'Music', 'Business', 'Other'];

export const FEATURED_SKILLS = [
  { name: 'Python', mark: 'Py', blurb: 'Automation, data and problem solving' },
  { name: 'React JS', mark: 'Re', blurb: 'Build fast, interactive web interfaces' },
  { name: 'Java', mark: 'Ja', blurb: 'Object-oriented code and DSA practice' },
  { name: 'Graphic Design', mark: 'Gd', blurb: 'Posters, branding and visual stories' },
  { name: 'UI/UX Design', mark: 'Ux', blurb: 'Wireframes, Figma and user research' },
  { name: 'Spoken English', mark: 'En', blurb: 'Fluency, confidence and interviews' },
];

export const sampleProfiles = [
  {
    id: 'p1', name: 'Ananya Rao', category: 'Programming', level: 'Advanced',
    teaches: ['Python'], learns: ['UI/UX Design'],
    bio: 'Final-year student who builds data scripts and loves explaining loops with real examples.',
  },
  {
    id: 'p2', name: 'Rahul Verma', category: 'Programming', level: 'Intermediate',
    teaches: ['Python', 'Pandas'], learns: ['Spoken English'],
    bio: 'Data-science enthusiast preparing for campus interviews and wants to speak with more confidence.',
  },
  {
    id: 'p3', name: 'Sneha Reddy', category: 'Programming', level: 'Intermediate',
    teaches: ['React JS', 'JavaScript'], learns: ['Java'],
    bio: 'Builds small web apps for college clubs. Happy to walk through hooks and routing.',
  },
  {
    id: 'p4', name: 'Karthik Nair', category: 'Programming', level: 'Advanced',
    teaches: ['React JS', 'HTML & CSS'], learns: ['UI/UX Design'],
    bio: 'Frontend intern who can help you ship a portfolio site. Wants to improve design sense.',
  },
  {
    id: 'p5', name: 'Priya Sharma', category: 'Programming', level: 'Advanced',
    teaches: ['Java', 'DSA'], learns: ['React JS'],
    bio: 'Competitive programmer. Can teach collections, OOP and interview-style problem solving.',
  },
  {
    id: 'p6', name: 'Arjun Mehta', category: 'Programming', level: 'Intermediate',
    teaches: ['Java', 'Spring Boot'], learns: ['Python'],
    bio: 'Backend learner who enjoys pair programming sessions and code reviews.',
  },
  {
    id: 'p7', name: 'Meera Iyer', category: 'Design', level: 'Advanced',
    teaches: ['Graphic Design', 'Canva'], learns: ['Spoken English'],
    bio: 'Designs posters and brand kits for college fests. Can teach layout, colour and typography.',
  },
  {
    id: 'p8', name: 'Vikram Das', category: 'Design', level: 'Intermediate',
    teaches: ['Graphic Design', 'Photoshop'], learns: ['Java'],
    bio: 'Freelance designer moving towards app development. Photo editing is my strong suit.',
  },
  {
    id: 'p9', name: 'Divya Menon', category: 'Design', level: 'Advanced',
    teaches: ['UI/UX Design', 'Figma'], learns: ['Python'],
    bio: 'Product design student. I can help you go from sketch to clickable prototype in a weekend.',
  },
  {
    id: 'p10', name: 'Rohan Gupta', category: 'Design', level: 'Intermediate',
    teaches: ['UI/UX Design', 'User Research'], learns: ['React JS'],
    bio: 'Runs usability tests for student projects. Wants to turn designs into working interfaces.',
  },
  {
    id: 'p11', name: 'Lakshmi Prasad', category: 'Language', level: 'Advanced',
    teaches: ['Spoken English', 'Interview Prep'], learns: ['Graphic Design'],
    bio: 'Communication trainer. Mock interviews, pronunciation and group-discussion practice.',
  },
  {
    id: 'p12', name: 'Fatima Khan', category: 'Language', level: 'Advanced',
    teaches: ['Spoken English', 'Public Speaking'], learns: ['Python'],
    bio: 'Debate club captain. I can help you speak clearly and calmly in front of a crowd.',
  },
];

// A few incoming requests so the "Received" tab has something to accept or reject.
export function createSampleRequests() {
  const now = Date.now();
  const minute = 60 * 1000;
  return [
    {
      id: 'r-seed-1', direction: 'received', profileId: 'p5', status: 'Pending',
      message: 'Hi! I can teach you Java in exchange for a few React JS sessions.',
      createdAt: now - 45 * minute,
    },
    {
      id: 'r-seed-2', direction: 'received', profileId: 'p9', status: 'Pending',
      message: 'I would love to swap UI/UX tips for some Python basics.',
      createdAt: now - 5 * 60 * minute,
    },
    {
      id: 'r-seed-3', direction: 'received', profileId: 'p12', status: 'Accepted',
      message: 'Public speaking practice for Python lessons? Happy to start this week.',
      createdAt: now - 26 * 60 * minute,
    },
  ];
}
