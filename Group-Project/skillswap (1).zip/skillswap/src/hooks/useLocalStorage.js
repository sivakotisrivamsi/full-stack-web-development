import { useEffect, useState } from 'react';

/**
 * Like useState, but the value is saved to localStorage and restored on refresh.
 * `initialValue` can be a value or a function that returns one.
 */
export default function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const stored = window.localStorage.getItem(key);
      if (stored !== null) return JSON.parse(stored);
    } catch {
      // Ignore broken or blocked storage and fall back to the initial value
    }
    return typeof initialValue === 'function' ? initialValue() : initialValue;
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Storage can be full or disabled (private mode); the app still works in memory
    }
  }, [key, value]);

  return [value, setValue];
}
