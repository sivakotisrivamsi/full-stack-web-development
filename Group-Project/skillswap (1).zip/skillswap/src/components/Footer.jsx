import { Link } from 'react-router-dom';
import Logo from './Logo.jsx';
import { FEATURED_SKILLS } from '../data/sampleData.js';

const PAGES = [
  { to: '/', label: 'Home' },
  { to: '/explore', label: 'Explore Skills' },
  { to: '/offer', label: 'Offer Your Skill' },
  { to: '/requests', label: 'Swap Requests' },
  { to: '/how-it-works', label: 'How It Works' },
];

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__brand">
          <Logo light />
          <p className="footer__text">
            SkillSwap is a free community where learners trade what they know for what they want to learn.
            No payments, just people helping each other grow.
          </p>
        </div>

        <nav aria-label="Footer">
          <h2 className="footer__heading">Pages</h2>
          <ul className="footer__list">
            {PAGES.map((p) => (
              <li key={p.to}>
                <Link to={p.to} className="footer__link">{p.label}</Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Popular skills">
          <h2 className="footer__heading">Popular skills</h2>
          <ul className="footer__list">
            {FEATURED_SKILLS.map((s) => (
              <li key={s.name}>
                <Link to={`/explore?q=${encodeURIComponent(s.name)}`} className="footer__link">{s.name}</Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      <div className="container footer__bottom">
        <p>&copy; {new Date().getFullYear()} SkillSwap. All rights reserved.</p>
        <p>Built with React as a student project.</p>
      </div>
    </footer>
  );
}
