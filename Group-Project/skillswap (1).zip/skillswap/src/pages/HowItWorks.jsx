import { Link } from 'react-router-dom';
import usePageTitle from '../hooks/usePageTitle.js';
import { ChatIcon, MatchIcon, UserPlusIcon } from '../components/Icons.jsx';

const STEPS = [
  {
    icon: UserPlusIcon,
    title: 'Share Your Skills',
    text: 'Create a profile with the skills you can teach and the ones you want to learn. It takes about a minute.',
  },
  {
    icon: MatchIcon,
    title: 'Find a Match',
    text: 'Search or filter the community to find someone who teaches what you need and wants what you know.',
  },
  {
    icon: ChatIcon,
    title: 'Start Swapping',
    text: 'Send a swap request. Once it is accepted, agree on times and start teaching each other.',
  },
];

const FAQ = [
  {
    q: 'Does SkillSwap cost anything?',
    a: 'No. Every exchange is skill for skill, so there are no fees and no payments between members.',
  },
  {
    q: 'Can I send more than one request to the same person?',
    a: 'No. Each member can receive one request from you. If you change your mind while it is pending, withdraw it from the Swap Requests page.',
  },
  {
    q: 'Where is my data stored?',
    a: 'In this browser only (localStorage). Your profiles and requests stay after a refresh, but they are not shared with other devices.',
  },
  {
    q: 'Can I list more than one skill?',
    a: 'Yes. List up to five skills you can teach and five you want to learn, separated by commas.',
  },
];

export default function HowItWorks() {
  usePageTitle('How It Works');

  return (
    <>
      <section className="page-header">
        <div className="container">
          <h1 className="page-header__title">How It Works</h1>
          <p className="page-header__lead">Three simple steps from "I want to learn" to your first swap.</p>
        </div>
      </section>

      <section className="section section--compact">
        <div className="container">
          <ol className="steps">
            {STEPS.map((step, index) => {
              const Icon = step.icon;
              return (
                <li className="step" key={step.title}>
                  <div className="step__top">
                    <span className="step__num">{index + 1}</span>
                    <span className="step__icon"><Icon width={24} height={24} /></span>
                  </div>
                  <h2 className="step__title">{step.title}</h2>
                  <p className="step__text">{step.text}</p>
                </li>
              );
            })}
          </ol>
          <div className="steps__actions">
            <Link to="/offer" className="btn btn--primary">Offer Your Skill</Link>
            <Link to="/explore" className="btn btn--secondary">Explore Skills</Link>
          </div>
        </div>
      </section>

      <section className="section section--tint">
        <div className="container faq">
          <h2 className="section__title">Common questions</h2>
          <div className="faq__list">
            {FAQ.map((item) => (
              <details className="faq__item" key={item.q}>
                <summary className="faq__question">{item.q}</summary>
                <p className="faq__answer">{item.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
