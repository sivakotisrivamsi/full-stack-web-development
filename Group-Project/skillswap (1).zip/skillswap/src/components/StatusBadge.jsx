import { CheckIcon, ClockIcon, CloseIcon } from './Icons.jsx';

const ICONS = { Pending: ClockIcon, Accepted: CheckIcon, Rejected: CloseIcon };

export default function StatusBadge({ status }) {
  const Icon = ICONS[status] ?? ClockIcon;
  return (
    <span className={`status status--${status.toLowerCase()}`}>
      <Icon width={14} height={14} />
      {status}
    </span>
  );
}
