import { Link } from 'react-router-dom';
import { CheckIcon, ClockIcon, CloseIcon } from './Icons.jsx';
import { useSkillSwap } from '../context/SkillSwapContext.jsx';

export default function Toast() {
  const { toast, dismissToast } = useSkillSwap();

  return (
    <div className="toast-region" role="status" aria-live="polite">
      {toast && (
        <div key={toast.id} className={`toast toast--${toast.type}`}>
          <span className="toast__icon">{toast.type === 'success' ? <CheckIcon width={18} height={18} /> : <ClockIcon width={18} height={18} />}</span>
          <p className="toast__text">{toast.message}</p>
          {toast.action && (
            <Link className="toast__action" to={toast.action.to} onClick={dismissToast}>
              {toast.action.label}
            </Link>
          )}
          <button type="button" className="toast__close" onClick={dismissToast} aria-label="Dismiss notification">
            <CloseIcon width={16} height={16} />
          </button>
        </div>
      )}
    </div>
  );
}
