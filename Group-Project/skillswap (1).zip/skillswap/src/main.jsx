import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { SkillSwapProvider } from './context/SkillSwapContext.jsx';
import './styles/global.css';
import './styles/components.css';
import './styles/pages.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <SkillSwapProvider>
        <App />
      </SkillSwapProvider>
    </BrowserRouter>
  </React.StrictMode>
);
