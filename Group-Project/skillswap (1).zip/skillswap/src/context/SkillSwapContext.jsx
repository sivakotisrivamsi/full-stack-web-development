import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage.js';
import { sampleProfiles, createSampleRequests } from '../data/sampleData.js';

const SkillSwapContext = createContext(null);

// There is no backend, so other members "reply" to your requests after a short delay.
const RESPONSE_DELAY_MS = 8000;

// Deterministic outcome so a given member always answers the same way (about 1 in 4 decline)
function decideOutcome(profileId) {
  let sum = 0;
  for (const ch of String(profileId)) sum += ch.charCodeAt(0);
  return sum % 4 === 0 ? 'Rejected' : 'Accepted';
}

export function SkillSwapProvider({ children }) {
  const [profiles, setProfiles] = useLocalStorage('skillswap.profiles.v1', sampleProfiles);
  const [requests, setRequests] = useLocalStorage('skillswap.requests.v1', createSampleRequests);

  // ---- Toast notifications -------------------------------------------------
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);

  const dismissToast = useCallback(() => {
    clearTimeout(toastTimer.current);
    setToast(null);
  }, []);

  const showToast = useCallback((message, type = 'success', action = null) => {
    clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), message, type, action });
    toastTimer.current = setTimeout(() => setToast(null), 4500);
  }, []);

  // ---- Profiles ------------------------------------------------------------
  const addProfile = useCallback(
    (data) => {
      const profile = { ...data, id: `u-${Date.now()}`, isOwn: true, createdAt: Date.now() };
      setProfiles((prev) => [profile, ...prev]);
      return profile;
    },
    [setProfiles]
  );

  const removeProfile = useCallback(
    (id) => {
      setProfiles((prev) => prev.filter((p) => p.id !== id));
      setRequests((prev) => prev.filter((r) => r.profileId !== id));
      showToast('Your listing was removed.', 'info');
    },
    [setProfiles, setRequests, showToast]
  );

  // ---- Requests ------------------------------------------------------------
  const sentStatusByProfile = useMemo(() => {
    const map = {};
    requests.forEach((r) => {
      if (r.direction === 'sent') map[r.profileId] = r.status;
    });
    return map;
  }, [requests]);

  const sendRequest = useCallback(
    (profileId) => {
      const target = profiles.find((p) => p.id === profileId);
      if (!target) return { ok: false, reason: 'missing' };
      if (target.isOwn) return { ok: false, reason: 'own' };

      const isDuplicate = (list) => list.some((r) => r.direction === 'sent' && r.profileId === profileId);
      if (isDuplicate(requests)) {
        showToast(`You already sent a request to ${target.name}.`, 'info', { to: '/requests', label: 'View requests' });
        return { ok: false, reason: 'duplicate' };
      }

      const request = {
        id: `r-${Date.now()}`,
        direction: 'sent',
        profileId,
        status: 'Pending',
        createdAt: Date.now(),
      };
      // Check again inside the updater so a double click can never create two requests
      setRequests((prev) => (isDuplicate(prev) ? prev : [request, ...prev]));
      showToast(`Request sent to ${target.name}.`, 'success', { to: '/requests', label: 'View requests' });
      return { ok: true, request };
    },
    [profiles, requests, setRequests, showToast]
  );

  const respondToRequest = useCallback(
    (id, status) => {
      const req = requests.find((r) => r.id === id);
      const who = profiles.find((p) => p.id === req?.profileId)?.name ?? 'this member';
      setRequests((prev) => prev.map((r) => (r.id === id ? { ...r, status } : r)));
      showToast(`You ${status.toLowerCase()} ${who}'s request.`, status === 'Accepted' ? 'success' : 'info');
    },
    [requests, profiles, setRequests, showToast]
  );

  const withdrawRequest = useCallback(
    (id) => {
      setRequests((prev) => prev.filter((r) => r.id !== id));
      showToast('Request withdrawn.', 'info');
    },
    [setRequests, showToast]
  );

  const resetData = useCallback(() => {
    setProfiles(sampleProfiles);
    setRequests(createSampleRequests());
    showToast('Demo data restored.', 'info');
  }, [setProfiles, setRequests, showToast]);

  // Simulated replies to pending requests you sent (also resumes after a page refresh)
  useEffect(() => {
    const timers = requests
      .filter((r) => r.direction === 'sent' && r.status === 'Pending')
      .map((r) => {
        const delay = Math.max(1500, r.createdAt + RESPONSE_DELAY_MS - Date.now());
        return setTimeout(() => {
          const outcome = decideOutcome(r.profileId);
          const who = profiles.find((p) => p.id === r.profileId)?.name ?? 'A member';
          setRequests((prev) =>
            prev.map((x) => (x.id === r.id && x.status === 'Pending' ? { ...x, status: outcome } : x))
          );
          showToast(
            outcome === 'Accepted' ? `${who} accepted your swap request.` : `${who} rejected your swap request.`,
            outcome === 'Accepted' ? 'success' : 'info',
            { to: '/requests', label: 'View requests' }
          );
        }, delay);
      });
    return () => timers.forEach(clearTimeout);
  }, [requests, profiles, setRequests, showToast]);

  // ---- Derived numbers -----------------------------------------------------
  const stats = useMemo(() => {
    const skills = new Set();
    profiles.forEach((p) => p.teaches.forEach((s) => skills.add(s.toLowerCase())));
    return {
      profiles: profiles.length,
      skills: skills.size,
      requests: requests.length,
      accepted: requests.filter((r) => r.status === 'Accepted').length,
    };
  }, [profiles, requests]);

  const pendingReceivedCount = requests.filter((r) => r.direction === 'received' && r.status === 'Pending').length;

  const value = {
    profiles,
    requests,
    stats,
    pendingReceivedCount,
    sentStatusByProfile,
    addProfile,
    removeProfile,
    sendRequest,
    respondToRequest,
    withdrawRequest,
    resetData,
    toast,
    dismissToast,
  };

  return <SkillSwapContext.Provider value={value}>{children}</SkillSwapContext.Provider>;
}

export function useSkillSwap() {
  const ctx = useContext(SkillSwapContext);
  if (!ctx) throw new Error('useSkillSwap must be used inside <SkillSwapProvider>');
  return ctx;
}
