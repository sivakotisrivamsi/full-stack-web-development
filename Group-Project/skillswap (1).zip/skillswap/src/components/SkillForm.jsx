import { useId, useRef, useState } from 'react';
import { CATEGORIES } from '../data/sampleData.js';
import { EMPTY_VALUES, LEVELS, parseSkills, validateProfile } from '../utils/validation.js';

function Field({ id, label, hint, error, children }) {
  return (
    <div className="field">
      <label className="field__label" htmlFor={id}>{label}</label>
      {children}
      {error ? (
        <p className="field__error" id={`${id}-error`}>{error}</p>
      ) : (
        hint && <p className="field__hint" id={`${id}-hint`}>{hint}</p>
      )}
    </div>
  );
}

/**
 * Profile form with validation.
 * - onSubmit(profileData) is called only when every field is valid
 * - onValuesChange(values) lets a parent show a live preview
 */
export default function SkillForm({ onSubmit, onValuesChange }) {
  const uid = useId();
  const formRef = useRef(null);
  const [values, setValues] = useState(EMPTY_VALUES);
  const [touched, setTouched] = useState({});
  const [submitAttempted, setSubmitAttempted] = useState(false);

  const errors = validateProfile(values);
  const showError = (field) => (touched[field] || submitAttempted) && errors[field];

  const id = (field) => `${uid}-${field}`;
  const inputProps = (field, hint = true) => ({
    id: id(field),
    name: field,
    value: values[field],
    onChange: handleChange,
    onBlur: () => setTouched((t) => ({ ...t, [field]: true })),
    'aria-invalid': showError(field) ? 'true' : 'false',
    'aria-describedby': showError(field) ? `${id(field)}-error` : hint ? `${id(field)}-hint` : undefined,
  });

  function handleChange(e) {
    const next = { ...values, [e.target.name]: e.target.value };
    setValues(next);
    onValuesChange?.(next);
  }

  function handleSubmit(e) {
    e.preventDefault();
    setSubmitAttempted(true);

    if (Object.keys(errors).length > 0) {
      // Move focus to the first field that needs attention
      formRef.current?.querySelector('[aria-invalid="true"]')?.focus();
      return;
    }

    onSubmit({
      name: values.name.trim(),
      category: values.category,
      level: values.level,
      teaches: parseSkills(values.teaches),
      learns: parseSkills(values.learns),
      bio: values.bio.trim(),
    });

    setValues(EMPTY_VALUES);
    setTouched({});
    setSubmitAttempted(false);
    onValuesChange?.(EMPTY_VALUES);
  }

  return (
    <form ref={formRef} className="form-card" onSubmit={handleSubmit} noValidate>
      <Field id={id('name')} label="Your name" error={showError('name')}>
        <input className="field__input" type="text" autoComplete="name" placeholder="e.g. Harshitha" {...inputProps('name', false)} />
      </Field>

      <div className="form-row">
        <Field id={id('category')} label="Main category" error={showError('category')}>
          <select className="field__input field__select" {...inputProps('category', false)}>
            <option value="">Select a category</option>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </Field>

        <Field id={id('level')} label="Your level">
          <select className="field__input field__select" {...inputProps('level', false)}>
            {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
          </select>
        </Field>
      </div>

      <Field
        id={id('teaches')}
        label="Skills you can teach"
        hint="Separate skills with commas, for example: Python, Pandas"
        error={showError('teaches')}
      >
        <input className="field__input" type="text" placeholder="Python, Pandas" {...inputProps('teaches')} />
      </Field>

      <Field
        id={id('learns')}
        label="Skills you want to learn"
        hint="For example: UI/UX Design, Spoken English"
        error={showError('learns')}
      >
        <input className="field__input" type="text" placeholder="UI/UX Design" {...inputProps('learns')} />
      </Field>

      <Field
        id={id('bio')}
        label="Short note (optional)"
        hint={`${values.bio.trim().length}/160 characters. Tell people how you like to learn or teach.`}
        error={showError('bio')}
      >
        <textarea className="field__input field__textarea" rows={3} placeholder="I enjoy pair programming and weekend sessions." {...inputProps('bio')} />
      </Field>

      <button type="submit" className="btn btn--primary btn--block">Add my skill profile</button>
    </form>
  );
}
