export const LEVELS = ['Beginner', 'Intermediate', 'Advanced'];

export const EMPTY_VALUES = {
  name: '',
  category: '',
  level: 'Beginner',
  teaches: '',
  learns: '',
  bio: '',
};

// "Python, React JS" -> ["Python", "React JS"] (trimmed, no duplicates)
export function parseSkills(text) {
  const seen = new Set();
  const skills = [];
  String(text)
    .split(/[,;\n]/)
    .map((s) => s.trim().replace(/\s+/g, ' '))
    .filter(Boolean)
    .forEach((skill) => {
      const key = skill.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        skills.push(skill);
      }
    });
  return skills;
}

function checkSkillList(text, emptyMessage) {
  const skills = parseSkills(text);
  if (skills.length === 0) return emptyMessage;
  if (skills.length > 5) return 'List up to 5 skills, separated by commas.';
  if (skills.some((s) => s.length > 30)) return 'Each skill must be 30 characters or fewer.';
  return '';
}

export function validateProfile(values) {
  const errors = {};

  const name = values.name.trim();
  if (!name) errors.name = 'Enter your name.';
  else if (name.length < 2) errors.name = 'Your name needs at least 2 characters.';
  else if (name.length > 40) errors.name = 'Keep your name under 40 characters.';
  else if (!/^[\p{L}][\p{L} .'-]*$/u.test(name)) errors.name = "Use letters, spaces, and . ' - only.";

  if (!values.category) errors.category = 'Choose a category for your main skill.';

  const teachError = checkSkillList(values.teaches, 'Add at least one skill you can teach.');
  if (teachError) errors.teaches = teachError;

  const learnError = checkSkillList(values.learns, 'Add at least one skill you want to learn.');
  if (learnError) errors.learns = learnError;

  if (!teachError && !learnError) {
    const teaching = new Set(parseSkills(values.teaches).map((s) => s.toLowerCase()));
    if (parseSkills(values.learns).some((s) => teaching.has(s.toLowerCase()))) {
      errors.learns = "A skill can't be in both lists. Choose something new to learn.";
    }
  }

  if (values.bio.trim().length > 160) errors.bio = 'Keep your note under 160 characters.';

  return errors;
}
