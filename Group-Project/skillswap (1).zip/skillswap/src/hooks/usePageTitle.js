import { useEffect } from 'react';

export default function usePageTitle(title) {
  useEffect(() => {
    document.title = title ? `${title} | SkillSwap` : 'SkillSwap | Trade skills, not money';
  }, [title]);
}
