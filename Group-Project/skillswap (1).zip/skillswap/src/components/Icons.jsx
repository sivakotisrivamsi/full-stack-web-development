// Small inline SVG icons (stroke style) so no icon library is needed.
const base = {
  width: 20,
  height: 20,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 2,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
  'aria-hidden': true,
  focusable: 'false',
};

const make = (children) =>
  function Icon(props) {
    return (
      <svg {...base} {...props}>
        {children}
      </svg>
    );
  };

export const SearchIcon = make(<><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>);
export const MenuIcon = make(<path d="M4 7h16M4 12h16M4 17h16" />);
export const CloseIcon = make(<path d="M6 6l12 12M18 6 6 18" />);
export const CheckIcon = make(<path d="M5 12.5l4.5 4.5L19 7.5" />);
export const ClockIcon = make(<><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>);
export const SwapIcon = make(
  <>
    <path d="M17 3l4 4-4 4" /><path d="M21 7H8a4 4 0 0 0-4 4" />
    <path d="M7 21l-4-4 4-4" /><path d="M3 17h13a4 4 0 0 0 4-4" />
  </>
);
export const TrashIcon = make(<><path d="M4 7h16" /><path d="M9 7V4h6v3" /><path d="M6 7l1 13h10l1-13" /></>);
export const UserPlusIcon = make(
  <><circle cx="10" cy="8" r="4" /><path d="M3 20c0-3.5 3-6 7-6" /><path d="M18 14v6M15 17h6" /></>
);
export const MatchIcon = make(<><circle cx="9" cy="12" r="5" /><circle cx="15" cy="12" r="5" /></>);
export const ChatIcon = make(<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z" />);
export const SendIcon = make(<><path d="M22 2 11 13" /><path d="M22 2l-7 20-4-9-9-4z" /></>);
export const InboxIcon = make(<><path d="M3 13l3-8h12l3 8" /><path d="M3 13v6h18v-6h-5a4 4 0 0 1-8 0z" /></>);
