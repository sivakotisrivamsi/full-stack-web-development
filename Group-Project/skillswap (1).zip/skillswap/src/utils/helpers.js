const TONES = ['tone-purple', 'tone-blue', 'tone-violet', 'tone-sky'];

export function initials(name) {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((word) => word.charAt(0).toUpperCase())
    .join('');
}

// Gives each person a stable avatar colour based on their id
export function toneFor(id) {
  let sum = 0;
  for (const ch of String(id)) sum += ch.charCodeAt(0);
  return TONES[sum % TONES.length];
}

export function timeAgo(timestamp) {
  const minutes = Math.floor(Math.max(0, Date.now() - timestamp) / 60000);
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hr ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days > 1 ? 's' : ''} ago`;
}

export function matchesQuery(profile, query) {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  const haystack = [profile.name, profile.category, profile.bio || '', ...profile.teaches, ...profile.learns]
    .join(' ')
    .toLowerCase();
  return haystack.includes(q);
}

export function teachesSkill(profile, skill) {
  return profile.teaches.some((t) => t.toLowerCase() === skill.toLowerCase());
}
