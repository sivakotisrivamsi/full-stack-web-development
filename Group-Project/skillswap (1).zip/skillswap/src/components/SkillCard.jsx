import { Link } from 'react-router-dom';
import { initials, toneFor } from '../utils/helpers.js';
import { CheckIcon, ClockIcon, CloseIcon, SwapIcon, TrashIcon } from './Icons.jsx';

const STATUS_LABEL = {
  Pending: 'Request pending',
  Accepted: 'Swap accepted',
  Rejected: 'Request rejected',
};
const STATUS_ICON = { Pending: ClockIcon, Accepted: CheckIcon, Rejected: CloseIcon };

/**
 * One member's skill profile.
 * - requestStatus: the status of the request you already sent to this member (if any)
 * - preview: show the card without any action button (used on the Offer page)
 */
export default function SkillCard({ profile, requestStatus = null, onRequest, onRemove, preview = false }) {
  let action = null;

  if (!preview) {
    if (profile.isOwn) {
      action = (
        <div className="skill-card__own">
          <span className="skill-card__own-label">Your listing</span>
          <button type="button" className="btn btn--ghost btn--small" onClick={() => onRemove?.(profile)}>
            <TrashIcon width={16} height={16} />
            Remove
          </button>
        </div>
      );
    } else if (requestStatus) {
      const Icon = STATUS_ICON[requestStatus];
      action = (
        <Link to="/requests" className={`btn btn--block btn--${requestStatus.toLowerCase()}`}>
          <Icon width={18} height={18} />
          {STATUS_LABEL[requestStatus]}
        </Link>
      );
    } else {
      action = (
        <button type="button" className="btn btn--primary btn--block" onClick={() => onRequest?.(profile)}>
          <SwapIcon width={18} height={18} />
          Request Skill Swap
        </button>
      );
    }
  }

  return (
    <article className="skill-card">
      <header className="skill-card__head">
        <span className={`avatar ${toneFor(profile.id)}`} aria-hidden="true">{initials(profile.name)}</span>
        <div className="skill-card__who">
          <h3 className="skill-card__name">{profile.name}</h3>
          <p className="skill-card__level">{profile.level}</p>
        </div>
        <span className="pill">{profile.category}</span>
      </header>

      <div className="skill-card__body">
        <div className="skill-card__group">
          <p className="skill-card__label">Can teach</p>
          <ul className="chips chips--purple">
            {profile.teaches.map((skill) => <li key={skill}>{skill}</li>)}
          </ul>
        </div>
        <div className="skill-card__group">
          <p className="skill-card__label">Wants to learn</p>
          <ul className="chips chips--blue">
            {profile.learns.map((skill) => <li key={skill}>{skill}</li>)}
          </ul>
        </div>
        {profile.bio && <p className="skill-card__bio">{profile.bio}</p>}
      </div>

      {action && <footer className="skill-card__footer">{action}</footer>}
    </article>
  );
}
