# SkillSwap Platform

A skill-exchange website built with React, React Router, and plain CSS.
Members teach what they know, learn what they want, and trade skills without paying money.

## Run it in VS Code

1. Install **Node.js 18 or newer** from https://nodejs.org (check with `node -v`).
2. In VS Code choose **File > Open Folder** and open the `skillswap` folder.
3. Open the terminal with **Terminal > New Terminal** (or Ctrl + `).
4. Install the dependencies (first time only):
   ```
   npm install
   ```
5. Start the development server:
   ```
   npm run dev
   ```
6. Open http://localhost:5173 in your browser. It reloads when you save a file.

To stop the server press Ctrl + C. To create a production build run `npm run build`, then `npm run preview`.

## Project structure

```
skillswap/
├── index.html
├── package.json
├── vite.config.js
├── public/favicon.svg
└── src/
    ├── main.jsx                  App entry (Router + provider)
    ├── App.jsx                   Routes and page layout
    ├── context/SkillSwapContext.jsx   Profiles, requests, toasts, localStorage
    ├── hooks/                    useLocalStorage, usePageTitle
    ├── data/sampleData.js        Starter profiles and requests
    ├── utils/                    helpers.js, validation.js
    ├── components/               Navbar, Footer, Logo, SkillCard, SkillForm,
    │                             SearchBar, CategoryFilter, RequestCard,
    │                             StatusBadge, Toast, SwapVisual, Icons
    ├── pages/                    Home, Explore, Offer, Requests, HowItWorks, NotFound
    └── styles/                   global.css, components.css, pages.css
```

## How the main features work

- **Explore Skills**: search box (also reads `?q=` from the URL) and category filters.
- **Offer Your Skill**: validated form with a live preview. A new profile is added to Explore immediately.
- **Swap Requests**: you cannot send two requests to the same member. Pending requests can be withdrawn.
  Requests you receive can be accepted or rejected.
- **Persistence**: profiles and requests are saved in `localStorage`, so they survive a refresh.
- **Simulated replies**: there is no backend, so members answer your requests about 8 seconds after you send them.
  This is only for demonstration. Replace `RESPONSE_DELAY_MS` logic in `SkillSwapContext.jsx` with real API calls if you add a server.
- **Reset**: use "Reset demo data" at the bottom of the Swap Requests page, or clear the site data in your browser.
