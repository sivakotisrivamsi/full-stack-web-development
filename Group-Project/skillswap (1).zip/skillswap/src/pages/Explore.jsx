import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import usePageTitle from '../hooks/usePageTitle.js';
import { useSkillSwap } from '../context/SkillSwapContext.jsx';
import { CATEGORIES } from '../data/sampleData.js';
import { matchesQuery } from '../utils/helpers.js';
import SkillCard from '../components/SkillCard.jsx';
import SearchBar from '../components/SearchBar.jsx';
import CategoryFilter from '../components/CategoryFilter.jsx';

export default function Explore() {
  usePageTitle('Explore Skills');
  const { profiles, sentStatusByProfile, sendRequest, removeProfile } = useSkillSwap();
  const [searchParams, setSearchParams] = useSearchParams();
  const [category, setCategory] = useState('All');

  // The search text lives in the URL (?q=Python) so links from the Home page can pre-fill it
  const query = searchParams.get('q') ?? '';
  const setQuery = (value) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set('q', value);
    else next.delete('q');
    setSearchParams(next, { replace: true });
  };

  const categories = ['All', ...CATEGORIES.filter((c) => profiles.some((p) => p.category === c))];
  const counts = { All: profiles.length };
  profiles.forEach((p) => {
    counts[p.category] = (counts[p.category] ?? 0) + 1;
  });

  const results = profiles.filter(
    (p) => (category === 'All' || p.category === category) && matchesQuery(p, query)
  );

  const clearFilters = () => {
    setCategory('All');
    setQuery('');
  };

  return (
    <>
      <section className="page-header">
        <div className="container">
          <h1 className="page-header__title">Explore Skills</h1>
          <p className="page-header__lead">
            Browse members, find a match for what you want to learn, and send a swap request.
          </p>
          <SearchBar value={query} onChange={setQuery} placeholder="Search by skill, name or category" />
        </div>
      </section>

      <section className="section section--compact">
        <div className="container">
          <div className="toolbar">
            <CategoryFilter categories={categories} active={category} onChange={setCategory} counts={counts} />
            <p className="toolbar__count" aria-live="polite">
              Showing {results.length} of {profiles.length} profiles
            </p>
          </div>

          {results.length > 0 ? (
            <div className="card-grid">
              {results.map((profile) => (
                <SkillCard
                  key={profile.id}
                  profile={profile}
                  requestStatus={sentStatusByProfile[profile.id] ?? null}
                  onRequest={() => sendRequest(profile.id)}
                  onRemove={() => removeProfile(profile.id)}
                />
              ))}
            </div>
          ) : (
            <div className="empty">
              <h2 className="empty__title">No profiles match your search</h2>
              <p className="empty__text">Try a different keyword, switch category, or add your own skill to the list.</p>
              <div className="empty__actions">
                <button type="button" className="btn btn--secondary" onClick={clearFilters}>Clear filters</button>
                <Link to="/offer" className="btn btn--primary">Offer Your Skill</Link>
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
