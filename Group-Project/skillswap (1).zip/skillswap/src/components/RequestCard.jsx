import { initials, timeAgo, toneFor } from '../utils/helpers.js';
import StatusBadge from './StatusBadge.jsx';
import { CheckIcon, CloseIcon, TrashIcon } from './Icons.jsx';

/**
 * mode="sent"     -> you asked this member to teach you (you can withdraw while pending)
 * mode="received" -> this member asked to learn from you (you can accept or reject while pending)
 */
export default function RequestCard({ request, profile, mode, onWithdraw, onRespond }) {
  const isSent = mode === 'sent';

  return (
    <article className="request-card">
      <span className={`avatar avatar--lg ${toneFor(profile.id)}`} aria-hidden="true">{initials(profile.name)}</span>

      <div className="request-card__main">
        <div className="request-card__top">
          <h3 className="request-card__title">
            {isSent ? `You asked ${profile.name} to swap skills` : `${profile.name} wants to swap skills`}
          </h3>
          <StatusBadge status={request.status} />
        </div>

        <dl className="request-card__details">
          <div>
            <dt>{isSent ? 'You will learn' : 'They can teach'}</dt>
            <dd>{profile.teaches.join(', ')}</dd>
          </div>
          <div>
            <dt>They want to learn</dt>
            <dd>{profile.learns.join(', ')}</dd>
          </div>
        </dl>

        {request.message && <p className="request-card__message">&ldquo;{request.message}&rdquo;</p>}
        <p className="request-card__time">{timeAgo(request.createdAt)}</p>
      </div>

      {request.status === 'Pending' && (
        <div className="request-card__actions">
          {isSent ? (
            <button type="button" className="btn btn--ghost btn--small" onClick={() => onWithdraw(request.id)}>
              <TrashIcon width={16} height={16} />
              Withdraw
            </button>
          ) : (
            <>
              <button type="button" className="btn btn--primary btn--small" onClick={() => onRespond(request.id, 'Accepted')}>
                <CheckIcon width={16} height={16} />
                Accept
              </button>
              <button type="button" className="btn btn--secondary btn--small" onClick={() => onRespond(request.id, 'Rejected')}>
                <CloseIcon width={16} height={16} />
                Reject
              </button>
            </>
          )}
        </div>
      )}
    </article>
  );
}
