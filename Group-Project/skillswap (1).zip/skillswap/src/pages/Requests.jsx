import { useState } from 'react';
import { Link } from 'react-router-dom';
import usePageTitle from '../hooks/usePageTitle.js';
import { useSkillSwap } from '../context/SkillSwapContext.jsx';
import RequestCard from '../components/RequestCard.jsx';
import { InboxIcon, SendIcon } from '../components/Icons.jsx';

const STATUSES = ['Pending', 'Accepted', 'Rejected'];

export default function Requests() {
  usePageTitle('Swap Requests');
  const { requests, profiles, withdrawRequest, respondToRequest, resetData } = useSkillSwap();

  const sent = requests.filter((r) => r.direction === 'sent');
  const received = requests.filter((r) => r.direction === 'received');

  const [tab, setTab] = useState(sent.length > 0 ? 'sent' : 'received');
  const [statusFilter, setStatusFilter] = useState('All');

  const current = tab === 'sent' ? sent : received;
  const visible = current
    .filter((r) => statusFilter === 'All' || r.status === statusFilter)
    .sort((a, b) => b.createdAt - a.createdAt);

  const countStatus = (status) => requests.filter((r) => r.status === status).length;

  const handleReset = () => {
    if (window.confirm('Restore the sample profiles and requests? Your own profiles and requests will be removed.')) {
      resetData();
      setTab('received');
      setStatusFilter('All');
    }
  };

  return (
    <>
      <section className="page-header">
        <div className="container">
          <h1 className="page-header__title">Swap Requests</h1>
          <p className="page-header__lead">
            Track the requests you have sent and respond to people who want to learn from you.
          </p>
          <ul className="summary">
            {STATUSES.map((status) => (
              <li key={status} className={`summary__item summary__item--${status.toLowerCase()}`}>
                <span className="summary__value">{countStatus(status)}</span>
                <span className="summary__label">{status}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section section--compact">
        <div className="container">
          <div className="toolbar">
            <div className="tabs" role="tablist" aria-label="Request type">
              <button
                type="button" role="tab" id="tab-sent" aria-controls="panel-requests"
                aria-selected={tab === 'sent'} className="tab" onClick={() => setTab('sent')}
              >
                <SendIcon width={16} height={16} />
                Sent ({sent.length})
              </button>
              <button
                type="button" role="tab" id="tab-received" aria-controls="panel-requests"
                aria-selected={tab === 'received'} className="tab" onClick={() => setTab('received')}
              >
                <InboxIcon width={16} height={16} />
                Received ({received.length})
              </button>
            </div>

            <div className="filters" role="group" aria-label="Filter by status">
              {['All', ...STATUSES].map((status) => (
                <button
                  key={status} type="button" aria-pressed={statusFilter === status}
                  className={`filter-chip${statusFilter === status ? ' is-active' : ''}`}
                  onClick={() => setStatusFilter(status)}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>

          <div id="panel-requests" role="tabpanel" aria-labelledby={`tab-${tab}`}>
            {visible.length > 0 ? (
              <div className="request-list">
                {visible.map((request) => {
                  const profile = profiles.find((p) => p.id === request.profileId);
                  if (!profile) return null;
                  return (
                    <RequestCard
                      key={request.id}
                      request={request}
                      profile={profile}
                      mode={tab}
                      onWithdraw={withdrawRequest}
                      onRespond={respondToRequest}
                    />
                  );
                })}
              </div>
            ) : (
              <div className="empty">
                {current.length === 0 ? (
                  tab === 'sent' ? (
                    <>
                      <h2 className="empty__title">You haven't sent any requests yet</h2>
                      <p className="empty__text">Find a member who teaches what you want to learn and send a swap request.</p>
                      <div className="empty__actions">
                        <Link to="/explore" className="btn btn--primary">Explore Skills</Link>
                      </div>
                    </>
                  ) : (
                    <>
                      <h2 className="empty__title">No requests for your skills yet</h2>
                      <p className="empty__text">Add a clear skill profile so other learners can find you.</p>
                      <div className="empty__actions">
                        <Link to="/offer" className="btn btn--primary">Offer Your Skill</Link>
                      </div>
                    </>
                  )
                ) : (
                  <>
                    <h2 className="empty__title">No {statusFilter.toLowerCase()} requests here</h2>
                    <p className="empty__text">Try another status to see the rest of your requests.</p>
                    <div className="empty__actions">
                      <button type="button" className="btn btn--secondary" onClick={() => setStatusFilter('All')}>Show all</button>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          <p className="requests-note">
            Members reply to your sent requests a few seconds after you send them, so you can see each status change.
            {' '}
            <button type="button" className="link-button" onClick={handleReset}>Reset demo data</button>
          </p>
        </div>
      </section>
    </>
  );
}
