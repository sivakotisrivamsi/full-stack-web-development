import { useEffect, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import Logo from './Logo.jsx';
import { MenuIcon, CloseIcon } from './Icons.jsx';
import { useSkillSwap } from '../context/SkillSwapContext.jsx';

const NAV_LINKS = [
  { to: '/', label: 'Home', end: true },
  { to: '/explore', label: 'Explore Skills' },
  { to: '/offer', label: 'Offer Your Skill' },
  { to: '/requests', label: 'Swap Requests' },
  { to: '/how-it-works', label: 'How It Works' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const { pendingReceivedCount } = useSkillSwap();

  // Close the mobile menu after navigating
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  // Close with the Escape key
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <header className="navbar">
      <div className="container navbar__inner">
        <Logo />

        <button
          type="button"
          className="navbar__toggle"
          aria-expanded={open}
          aria-controls="primary-nav"
          aria-label={open ? 'Close menu' : 'Open menu'}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <CloseIcon /> : <MenuIcon />}
        </button>

        <nav id="primary-nav" className={`navbar__links${open ? ' is-open' : ''}`} aria-label="Primary">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              className={({ isActive }) => `navbar__link${isActive ? ' is-active' : ''}`}
            >
              {link.label}
              {link.to === '/requests' && pendingReceivedCount > 0 && (
                <span className="navbar__badge" aria-label={`${pendingReceivedCount} pending`}>
                  {pendingReceivedCount}
                </span>
              )}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
}
