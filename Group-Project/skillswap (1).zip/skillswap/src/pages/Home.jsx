import { Link } from 'react-router-dom';
import usePageTitle from '../hooks/usePageTitle.js';
import { useSkillSwap } from '../context/SkillSwapContext.jsx';
import { FEATURED_SKILLS } from '../data/sampleData.js';
import { teachesSkill, toneFor } from '../utils/helpers.js';
import SwapVisual from '../components/SwapVisual.jsx';

export default function Home() {
  usePageTitle('');
  const { profiles, stats } = useSkillSwap();

  const statItems = [
    { value: stats.profiles, label: 'Skill profiles' },
    { value: stats.skills, label: 'Skills on offer' },
    { value: stats.requests, label: 'Learning requests' },
    { value: stats.accepted, label: 'Swaps accepted' },
  ];

  return (
    <>
      <section className="hero">
        <div className="container hero__grid">
          <div className="hero__copy">
            <h1 className="hero__title">Your Skills Have More to Give.</h1>
            <p className="hero__lead">
              SkillSwap connects people who want to learn with people who love to teach. Trade a skill you
              already have for one you want to build, with no payments involved.
            </p>
            <div className="hero__actions">
              <Link to="/explore" className="btn btn--primary">Explore Skills</Link>
              <Link to="/offer" className="btn btn--secondary">Offer Your Skill</Link>
            </div>
            <p className="hero__note">Free to join. Every swap is skill for skill.</p>
          </div>
          <SwapVisual />
        </div>
      </section>

      <section className="container stats" aria-label="SkillSwap in numbers">
        <dl className="stats__grid">
          {statItems.map((item) => (
            <div className="stat" key={item.label}>
              <dt className="stat__label">{item.label}</dt>
              <dd className="stat__value">{item.value}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="section">
        <div className="container">
          <div className="section__head">
            <h2 className="section__title">Find someone to swap with</h2>
            <p className="section__lead">Pick a skill to see who is teaching it right now.</p>
          </div>
          <ul className="topic-grid">
            {FEATURED_SKILLS.map((skill) => {
              const count = profiles.filter((p) => teachesSkill(p, skill.name)).length;
              return (
                <li key={skill.name}>
                  <Link className="topic-card" to={`/explore?q=${encodeURIComponent(skill.name)}`}>
                    <span className={`avatar avatar--lg ${toneFor(skill.name)}`} aria-hidden="true">{skill.mark}</span>
                    <span className="topic-card__body">
                      <span className="topic-card__name">{skill.name}</span>
                      <span className="topic-card__blurb">{skill.blurb}</span>
                    </span>
                    <span className="topic-card__count">
                      {count} {count === 1 ? 'teacher' : 'teachers'}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      </section>

      <section className="section section--tint">
        <div className="container cta">
          <div>
            <h2 className="section__title">Know something others want to learn?</h2>
            <p className="section__lead">Create a profile in under a minute and start receiving swap requests.</p>
          </div>
          <div className="cta__actions">
            <Link to="/offer" className="btn btn--primary">Offer Your Skill</Link>
            <Link to="/how-it-works" className="btn btn--secondary">See how it works</Link>
          </div>
        </div>
      </section>
    </>
  );
}
